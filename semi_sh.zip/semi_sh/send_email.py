import re
import smtplib
import transcript_processor as nlp
 
#to = 'srchaitanya@gmail.com'
to = 'visa.it.87@gmail.com'
gmail_user = 'swetha14oct1996@gmail.com'
gmail_pwd = 'owbufgrjckkxcepb'
smtpserver = smtplib.SMTP("smtp.gmail.com",587)
smtpserver.ehlo()
smtpserver.starttls()
smtpserver.ehlo() # extra characters to permit edit
smtpserver.login(gmail_user, gmail_pwd)
header = 'To:' + to + '\n' + 'From: ' + gmail_user + '\n' + 'Subject:Meeting Minutes \n'
print(header)
file = open( "transcript.txt", "r")
lines = file.readlines()
file.close()
text = ''
new_text = ''
for line in lines:
	text = re.sub(r'.*\d{2}\:\d{2}\:\d{2}\ .', "", line)
	new_text += text
	with open('transcripted.txt', 'w') as the_file:
		the_file.write(new_text)
t_proc = nlp.TranscriptAnalyzer('transcripted.txt', 5)
res = {'summary': t_proc.text_summary(), "action_items": t_proc.retrieve_action_items(), "frequently_discussed_topics": t_proc.frequently_discussed_topics(), "concepts_discussed": t_proc.concepts_discussed(),"calendar_events": t_proc.retrieve_calendar_items()}
templateMsg = '\n Minutes Summary :- \n'
templateMsg +=res['summary']

templateMsg += '\n\n Action Items :- \n'
templateMsg +=str(res['action_items'])

templateMsg += '\n\n Frequently Discussed Topics :- \n'
templateMsg +=str(res['frequently_discussed_topics'])

templateMsg += '\n\n Concepts Discussed :- \n'
templateMsg +=str(res['concepts_discussed'])


#msg = header + template
msg = header + '\n'+ templateMsg
 
print(msg)
smtpserver.sendmail(gmail_user, to, msg)
print('done!')
smtpserver.quit()