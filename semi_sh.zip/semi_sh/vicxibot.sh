rm transcript.txt 

rm ./parts/*

echo "Start Chunking:" 

ffmpeg -i source/input.wav -f segment -segment_time 50 -c copy parts/out%09d.wav  

rm ./parts/out000000000.wav
##ls -U | head -n1 | xargs rm ./parts/*

echo "Start Transcription:"  

python fast.py

echo "Start NLP:" 

python send_email.py

clear

cat output.txt




