import re
import transcript_processor as nlp



def main():
    # read file line by line
	file = open( "transcript.txt", "r")
	lines = file.readlines()
	file.close()
	text = ''
	new_text = ''
	for line in lines:
		text = re.sub(r'.*\d{2}\:\d{2}\:\d{2}\ .', "", line)
		new_text += text
		with open('transcripted.txt', 'w') as the_file:
			the_file.write(new_text)
			
	t_proc = nlp.TranscriptAnalyzer('transcripted.txt', 5)
	#res = {'summary': t_proc.text_summary(), "action_items": t_proc.retrieve_action_items(), "calendar_events": t_proc.retrieve_calendar_items()}
	#res = {'summary': t_proc.text_summary(), "action_items": t_proc.retrieve_action_items(), "frequently_discussed_topics": t_proc.frequently_discussed_topics(),"calendar_events": t_proc.retrieve_calendar_items()}
	res = {'summary': t_proc.text_summary(), "action_items": t_proc.retrieve_action_items(), "frequently_discussed_topics": t_proc.frequently_discussed_topics(), "concepts_discussed": t_proc.concepts_discussed(),"calendar_events": t_proc.retrieve_calendar_items()}
	print("RES - ",res)
	
	return res
		
if __name__ == '__main__':
	main()